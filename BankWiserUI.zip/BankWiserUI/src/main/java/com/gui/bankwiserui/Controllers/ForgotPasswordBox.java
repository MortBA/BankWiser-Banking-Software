package com.gui.bankwiserui.Controllers;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;


public class ForgotPasswordBox{
    public void display(String fxml) throws IOException{
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxml));
            Stage forgotPasswordWindow = new Stage();
            forgotPasswordWindow.initModality(Modality.APPLICATION_MODAL);
            forgotPasswordWindow.setTitle("Forgot Password");
            Scene scene2 = new Scene(root);
            forgotPasswordWindow.setScene(scene2);
            forgotPasswordWindow.showAndWait();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


/*private static Stage forgotPasswordWindow;
    public void display(String fxml) throws IOException {
        try{
            Parent root = FXMLLoader.load(getClass().getResource(fxml));
            Stage forgotPasswordWindow = new Stage();
            forgotPasswordWindow.initModality(Modality.APPLICATION_MODAL);
            forgotPasswordWindow.setMaxHeight(600);
            forgotPasswordWindow.setMaxWidth(500);
            forgotPasswordWindow.setScene(new Scene(root));
            forgotPasswordWindow.showAndWait();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void start(Stage stage) throws Exception {

    }

    /*public void changeScene(String fxml) throws IOException {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxml));
            forgotPasswordWindow.setScene(new Scene(root));
            forgotPasswordWindow.show();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

     */

}




