module com.gui.bankwiserui {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.gui.bankwiserui to javafx.fxml;
    exports com.gui.bankwiserui;
    exports com.gui.bankwiserui.Controllers;
    opens com.gui.bankwiserui.Controllers to javafx.fxml;
}